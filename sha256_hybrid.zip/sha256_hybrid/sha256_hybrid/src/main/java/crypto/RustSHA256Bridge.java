// Insert the JNI Bridge Java code here
